/**
 * 
 */
/**
 * 
 */
module Task1 {
}