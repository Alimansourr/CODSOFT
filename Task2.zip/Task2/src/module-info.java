/**
 * 
 */
/**
 * 
 */
module Task2 {
}