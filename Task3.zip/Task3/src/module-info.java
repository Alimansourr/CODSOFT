/**
 * 
 */
/**
 * 
 */
module Task3 {
}