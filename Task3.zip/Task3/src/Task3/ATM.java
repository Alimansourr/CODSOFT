package Task3;


import java.util.Scanner;

public class ATM {

    
    public BankAccount bank;

  
    public ATM(BankAccount bankAccount) {
        this.bank = bankAccount;
    }

  
    public void withdraw(){
        System.out.println("Enter the amount you want to withdraw in your account: ");
        Scanner s = new Scanner(System.in);
        int amount = s.nextInt();

        withdraw(amount);
    }
    
    private void withdraw(int amount) {
        if (bank.getBalance() < amount) {
            System.out.println("Insufficient funds");
        }
        else
        {

        bank.withdraw(amount);
        System.out.println(" Sucessfull withdraw "+amount);
        }
    }


    
    public void deposit() {
        System.out.println("Enter the amount you want to deposit in your account: ");
        Scanner scanner = new Scanner(System.in);
        int amount = scanner.nextInt();

        deposit(amount);
    }


    private void deposit(int amount) {
        bank.deposit(amount);
        System.out.println("sucessfull deposit "+amount);
    }

  
    private void checkBalance() {
        System.out.println("Your account balance is: "+bank.getBalance());
    }

        
    
    public static void main(String[] args){
    	  BankAccount bankk = new BankAccount(0);
          ATM atm = new ATM(bankk);

          int choose;
          Scanner scanner = new Scanner(System.in);

          System.out.println("ATM Menu");
          System.out.println("1. Deposit");
          System.out.println("2. Withdraw");
          System.out.println("3. Check Balance");
          System.out.println("4. Exit Menu");

          do {
              System.out.println("Please enter your choice (1,2,3,4): ");
              choose = scanner.nextInt();

              if (choose == 1) {
                  atm.deposit();
              } else if (choose == 2) {
                  atm.withdraw();
              } else if (choose == 3) {
                  atm.checkBalance();
              } else if (choose == 4) {
                  System.exit(0);
              } else {
                  System.out.println("Invalid choice TRY AGAIN");
              }

          } while (choose != 4);

          scanner.close();
        
}
    }
    